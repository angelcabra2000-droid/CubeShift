using UnityEngine;

/// <summary>
/// Detecta, en las 4 direcciones horizontales alrededor del Jugador
/// (adelante, atrás, izquierda, derecha), si hay una pared que podría
/// convertirse en el nuevo piso al rotar el Mundo hacia ese lado.
///
/// Mapeo de rotaciones (tiene que coincidir EXACTO con RotadorMundo):
///   W: eje X, +90°  -> la pared de ADELANTE   pasa a ser el piso
///   S: eje X, -90°  -> la pared de ATRÁS      pasa a ser el piso
///   A: eje Z, +90°  -> la pared de IZQUIERDA  pasa a ser el piso
///   D: eje Z, -90°  -> la pared de DERECHA    pasa a ser el piso
///
/// El eje Y a propósito no se usa: rotar sobre el eje vertical nunca
/// cambia qué hay "abajo".
///
/// IMPORTANTE: el Jugador NUNCA se mueve ni rota — eso ahora lo hace
/// RotadorMundo, girando el Mundo alrededor del Jugador. Por eso este
/// sensor ya no necesita saber nada del Mundo ni calcular posiciones
/// proyectadas: solo mira hacia afuera desde la posición actual (fija)
/// del Jugador.
///
/// Colocar este script sobre el Jugador (junto con MovimientoJugador).
/// </summary>
public class SensorPisoRotacion : MonoBehaviour
{
    [Header("Referencias")]
    [Tooltip("Si se deja vacío, se usa este mismo transform (el del Jugador).")]
    [SerializeField] private Transform jugador;

    [Tooltip("La cámara (script CamaraVertices). Si se asigna, 'adelante/atrás/izquierda/derecha' son relativos a hacia dónde mira la vista actual. Si se deja vacío, se usan los ejes del propio Jugador.")]
    [SerializeField] private CamaraVertices camaraReferencia;

    [Header("Detección")]
    [Tooltip("Layer que usan las paredes/geometría del laberinto.")]
    [SerializeField] private LayerMask capaParedes;

    [Tooltip("Radio del SphereCast usado para detectar pared en cada dirección.")]
    [SerializeField] private float radioDeteccion = 0.3f;

    [Tooltip("Distancia a la que se busca pared, en cada una de las 4 direcciones horizontales.")]
    [SerializeField] private float distanciaDeteccion = 0.6f;

    [Tooltip("Solo se usa si el Jugador NO tiene Collider: distancia del centro del Jugador a sus pies. Con Collider se calcula sola.")]
    [SerializeField] private float alturaHastaPiesManual = 1f;

    private void Awake()
    {
        if (jugador == null) jugador = transform;

        // Si no asignaste la cámara a mano, la buscamos sola (Main Camera).
        if (camaraReferencia == null && Camera.main != null)
            camaraReferencia = Camera.main.GetComponent<CamaraVertices>();
    }

    /// <summary>
    /// Dirección mundial de "adelante": hacia adentro de la pantalla (W = se
    /// aleja de la cámara, S = se acerca). Sale de CamaraVertices si está
    /// disponible; si no, de hacia dónde apunta Camera.main (aplanado y
    /// ajustado al eje más cercano); y como último recurso, del propio Jugador.
    /// </summary>
    public Vector3 Adelante
    {
        get
        {
            if (camaraReferencia != null) return camaraReferencia.Adelante;

            Camera cam = Camera.main;
            if (cam != null)
            {
                Vector3 f = cam.transform.forward;
                f.y = 0f;
                if (f.sqrMagnitude > 0.0001f)
                    return Mathf.Abs(f.x) > Mathf.Abs(f.z)
                        ? new Vector3(Mathf.Sign(f.x), 0f, 0f)
                        : new Vector3(0f, 0f, Mathf.Sign(f.z));
            }

            return jugador.forward;
        }
    }

    /// <summary>Dirección mundial de "derecha" (hacia la derecha de la pantalla).</summary>
    public Vector3 Derecha => Vector3.Cross(Vector3.up, Adelante);

    public bool PuedeIrAdelante() => IntentarAdelante(out _);
    public bool PuedeIrAtras() => IntentarAtras(out _);
    public bool PuedeIrIzquierda() => IntentarIzquierda(out _);
    public bool PuedeIrDerecha() => IntentarDerecha(out _);

    /// <summary>Igual que PuedeIrX, pero además devuelve el impacto (para poder resaltar la pared encontrada).</summary>
    public bool IntentarAdelante(out RaycastHit hit) => Intentar(Adelante, out hit);
    public bool IntentarAtras(out RaycastHit hit) => Intentar(-Adelante, out hit);
    public bool IntentarIzquierda(out RaycastHit hit) => Intentar(-Derecha, out hit);
    public bool IntentarDerecha(out RaycastHit hit) => Intentar(Derecha, out hit);

    private bool Intentar(Vector3 direccion, out RaycastHit hit)
    {
        return Physics.SphereCast(jugador.position, radioDeteccion, direccion.normalized,
            out hit, distanciaDeteccion, capaParedes);
    }

    /// <summary>
    /// Para una dirección horizontal del mundo (normalmente jugador.forward,
    /// -jugador.forward, jugador.right o -jugador.right): ¿hay pared ahí
    /// (rotación válida), y si la hay, qué (eje, grados) hace falta pasarle
    /// a RotadorMundo para que esa pared termine siendo el piso?
    ///
    /// El eje se calcula con un producto cruz en vez de venir fijo (X o Z)
    /// porque el Jugador ahora puede girar libremente en el lugar (Flecha
    /// Izquierda/Derecha) — "adelante" ya no es siempre el eje Z del mundo.
    /// </summary>
    public bool ObtenerRotacionParaDireccion(Vector3 direccionMundial, out Vector3 eje, out float grados)
    {
        eje = Vector3.zero;
        grados = 0f;

        if (!Intentar(direccionMundial, out _)) return false;

        // Rotación de 90° que manda 'direccionMundial' exactamente a Vector3.down.
        eje = Vector3.Cross(direccionMundial, Vector3.down).normalized;
        grados = 90f;
        return true;
    }

    /// <summary>
    /// Distancia vertical desde el centro del Jugador hasta la suela de sus
    /// pies. Se calcula sola a partir del Collider del Jugador (sirve para
    /// cualquier tamaño de cápsula); si no tiene Collider, usa el valor manual.
    /// </summary>
    public float AlturaHastaPies
    {
        get
        {
            Collider col = jugador != null ? jugador.GetComponent<Collider>() : null;
            return col != null ? jugador.position.y - col.bounds.min.y : alturaHastaPiesManual;
        }
    }

    /// <summary>
    /// Cuánto hay que subir (+) o bajar (-) el Mundo, además del giro, para
    /// que la pared que está en 'direccionMundial' quede EXACTAMENTE bajo los
    /// pies del Jugador una vez convertida en piso.
    ///
    /// Al rotar alrededor del Jugador, una pared que estaba a distancia D
    /// (horizontal) queda a distancia D hacia abajo. Pero los pies están a
    /// AlturaHastaPies del centro; si D es menor, el Jugador se hunde en el
    /// piso, y si es mayor, flota. La corrección es D - AlturaHastaPies.
    /// </summary>
    public bool ObtenerCorreccionVertical(Vector3 direccionMundial, out float correccion)
    {
        correccion = 0f;
        Vector3 dir = direccionMundial.normalized;
        float distanciaPared;

        // Distancia exacta a la superficie de la pared (rayo fino desde el centro).
        if (Physics.Raycast(jugador.position, dir, out RaycastHit golpeRayo,
                distanciaDeteccion + radioDeteccion + 0.1f, capaParedes, QueryTriggerInteraction.Collide))
        {
            distanciaPared = golpeRayo.distance;
        }
        else if (Intentar(dir, out RaycastHit golpeEsfera))
        {
            // Respaldo: si el rayo fino no tocó (esquina), usamos el SphereCast.
            distanciaPared = golpeEsfera.distance + radioDeteccion;
        }
        else
        {
            return false;
        }

        correccion = distanciaPared - AlturaHastaPies;
        return true;
    }

    /// <summary>
    /// Si 'pared' es (el collider de) una de las 4 paredes candidatas AHORA
    /// MISMO, devuelve la dirección mundial (jugador.forward, etc.) que le
    /// corresponde — para poder disparar esa rotación desde un click.
    /// </summary>
    public bool DireccionParaPared(Collider pared, out Vector3 direccionMundial)
    {
        if (pared != null)
        {
            if (Intentar(Adelante, out RaycastHit h) && h.collider == pared) { direccionMundial = Adelante; return true; }
            if (Intentar(-Adelante, out h) && h.collider == pared) { direccionMundial = -Adelante; return true; }
            if (Intentar(-Derecha, out h) && h.collider == pared) { direccionMundial = -Derecha; return true; }
            if (Intentar(Derecha, out h) && h.collider == pared) { direccionMundial = Derecha; return true; }
        }
        direccionMundial = Vector3.zero;
        return false;
    }

    // --- DEBUG VISUAL ---
    private void OnDrawGizmosSelected()
    {
        if (jugador == null) jugador = transform;
        Dibujar(Adelante, Application.isPlaying && PuedeIrAdelante());
        Dibujar(-Adelante, Application.isPlaying && PuedeIrAtras());
        Dibujar(Derecha, Application.isPlaying && PuedeIrDerecha());
        Dibujar(-Derecha, Application.isPlaying && PuedeIrIzquierda());
    }

    private void Dibujar(Vector3 direccion, bool valido)
    {
        Gizmos.color = valido ? Color.green : Color.red;
        Vector3 origen = jugador.position;
        Vector3 destino = origen + direccion.normalized * distanciaDeteccion;
        Gizmos.DrawLine(origen, destino);
        Gizmos.DrawWireSphere(destino, radioDeteccion);
    }
}